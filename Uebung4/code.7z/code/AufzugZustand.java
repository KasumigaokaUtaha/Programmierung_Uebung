public enum AufzugZustand{
    Warten, Hoch, Runter
}
